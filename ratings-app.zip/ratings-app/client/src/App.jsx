import { Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Signup from './pages/Signup';

function Home() {
  return (
    <div className="container">
      <div className="card">
        <h2>Store Ratings Platform</h2>
        <p>Login as Admin, User, or Store Owner to see features.</p>
        <ul>
          <li><b>Admin:</b> Manage users, stores, and view stats</li>
          <li><b>User:</b> Browse stores and rate them</li>
          <li><b>Owner:</b> View ratings for your store</li>
        </ul>
        <Link to="/login" className="btn">Login</Link>
        <Link to="/signup" className="btn" style={{marginLeft:8}}>Sign Up</Link>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
    </Routes>
  );
}